const canvas = document.getElementById('canvas');
const c = canvas.getContext('2d');
let lineCoords;
let lineDirs = {
  x1: 'neg',
  y1: 'neg',
  x2: 'pos',
  y2: 'pos'
}
let strokeHue = 180;
let strokeLightness = 50;
let timeoutId;
let counter = 0;
setup();
window.addEventListener('resize', setup);

function setup() {
  clearTimeout(timeoutId);
  canvas.height = canvas.clientHeight;
  canvas.width = canvas.clientWidth;
  lineCoords = {
    x1: Math.floor(Math.random() * canvas.width),
    y1: Math.floor(Math.random() * canvas.height),
    x2: Math.floor(Math.random() * canvas.width),
    y2: Math.floor(Math.random() * canvas.height)
  }
  c.lineWidth = 3;
  c.lineCap = 'round';
  draw();
}

function draw() {
  if (counter > 500) {
    c.clearRect(0, 0, canvas.width, canvas.height);  
    counter = 0;
  }
  counter++;
  c.beginPath();
  c.moveTo(lineCoords.x1, lineCoords.y1);
  c.lineTo(lineCoords.x2, lineCoords.y2);
  c.strokeStyle = `hsl(${strokeHue}, ${strokeLightness}%, 85%)`;
  strokeHue = strokeHue + 5;
  if (strokeHue > 360) {
    strokeHue = 0;
  }
  c.stroke();
  
  const x1dir = lineDirs.x1;
  const y1dir = lineDirs.y1;
  const x2dir = lineDirs.x2;
  const y2dir = lineDirs.y2;
  
  ['x1', 'y1', 'x2', 'y2'].forEach((point) => {
    if (lineDirs[point] === 'neg' && lineCoords[point] < 0) {
      lineDirs[point] = 'pos';
    } else if (point[0] === 'y' && lineCoords[point] > canvas.height) {
      lineDirs[point] = 'neg';
    } else if (point[0] === 'x' && lineCoords[point] > canvas.width) {
      lineDirs[point] = 'neg';
    }
    
    if (lineDirs[point] === 'neg') {
      lineCoords[point] = lineCoords[point] - 25;
    } else {
      lineCoords[point] = lineCoords[point] + 25;
    }
    
  });

  timeoutId = setTimeout(() => draw(), 200);
}
